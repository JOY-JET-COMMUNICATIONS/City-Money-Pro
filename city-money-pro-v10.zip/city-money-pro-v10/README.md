# City-Money Pro v10

**Personal Investment & Goal Tracking Dashboard**  
Paper-trading simulator — no real money, no brokerage accounts.

---

## What’s New in v10

- Refined visual design system with improved spacing, typography & micro-interactions
- Cleaner dashboard hierarchy focused on Net Worth + progress
- Asset class filters (Crypto / Stocks / Mutual Funds)
- Search & filter on holdings and transaction history
- Smarter Goals experience with progress insights
- Quick-action floating bar on mobile
- Better empty states and loading feedback
- Keyboard shortcuts (press `?` for help)
- Improved accessibility and focus management
- More compact, professional footer
- Performance-conscious chart updates

---

## Features

- Multi-asset portfolio (Crypto + Stocks + Mutual Funds)
- Live crypto prices (CoinGecko) + offline fallback
- Goal tracking (Home, Education, Retirement, Custom) with progress bars
- Add Money / Withdraw (withdraw locked until $10,000 available)
- Buy & Sell with average cost basis
- Split Unrealized / Realized P&L
- Price alerts with unique IDs
- Transaction history (last 200) + CSV export + Clear History
- Multi-portfolio support
- Dark / Light theme
- Fully responsive + hamburger navigation
- 365-day session cookie
- Offline detection

---

## Quick Start

1. Open `index.html` in a modern browser  
   (or deploy the folder to GitHub Pages / Netlify / Vercel)

2. Sign in:
   - **Email:** `India@gmail.com`
   - **Password:** `Anthony`

> Credentials are never shown on the login screen.

---

## Project Structure

```
city-money-pro-v10/
├── index.html
├── styles.css
├── app.js
└── README.md
```

---

## Tech Stack

| Technology        | Purpose                        |
|-------------------|--------------------------------|
| HTML5             | Semantic structure             |
| CSS3 (variables)  | Theming & responsive layout    |
| Vanilla JavaScript| State, UI, API                 |
| Chart.js 4        | Charts                         |
| CoinGecko API     | Live crypto prices             |
| localStorage      | Persistence                    |
| Cookies           | 365-day login session          |

No build tools. No backend. No frameworks.

---

## Notes

- Holdings use **average cost basis**
- Withdrawals require **$10,000 available balance** to encourage goal discipline
- All data stays in your browser

---

## License

MIT
